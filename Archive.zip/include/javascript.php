
<script src="<?php echo $link;?>assets/js/jquery-3.6.4.min.js"></script>
<script src="<?php echo $link;?>assets/js/owl.carousel.min.js"></script>
<script src="<?php echo $link;?>assets/js/custom.js"></script>
<script src="<?php echo $link;?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $link;?>assets/js/font-awesome-min.js"></script>